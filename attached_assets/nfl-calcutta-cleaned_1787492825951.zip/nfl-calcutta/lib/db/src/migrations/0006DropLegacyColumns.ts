export const dropLegacyColumnsMigration = {
  version: "0006_drop_legacy_columns",
  sql: `
    -- bidders.consortium_id was replaced by the dated consortium_memberships
    -- table (migration 0005). The Drizzle schema no longer defines it; the
    -- column only survives in databases created before that migration.
    alter table bidders drop column if exists consortium_id;

    -- teams.bid_amount froze the 2025 auction prices onto the global franchise
    -- table. Per-season prices live in team_season_auctions; the last reader
    -- (the 2025 seed script) has been removed.
    alter table teams drop column if exists bid_amount;
  `,
} as const;
